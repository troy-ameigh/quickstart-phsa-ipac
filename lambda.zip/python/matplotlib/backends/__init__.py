# NOTE: plt.switch_backend() (called at import time) will add a "backend"
# attribute here for backcompat.
